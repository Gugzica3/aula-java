/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lab3ex3;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author unifgcardoso
 */
public class AgendaTeste {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        ArrayList<Pessoa> agenda = new ArrayList<>();
        boolean run = true;
        while (run) {
            Pessoa.mostraMenu();
            String entrada = input.nextLine();

            switch (entrada) {
                case "n":
                    System.out.println("nome do contato:");
                    String nome = input.nextLine();
                    System.out.println("telefone:");
                    int telefone = input.nextInt();
                    agenda.add(new Pessoa(nome, telefone));
                    break;
                case "d":
                    System.out.println("digite o nome do contato que voce quer excluir");
                    String nomeExcluir = input.nextLine();
                    for (int i = 0; i < agenda.size(); i++) {
                        if (agenda.get(i).getNome().equals(nomeExcluir)) {
                            agenda.remove(i);
                            System.out.println("Contato excluido");
                            break;
                        }
                        else
                            System.out.println("Contato nao encontrado");
                    }
                    break;
                case "p":
                    if(agenda.isEmpty()){
                        System.out.println("Nenhum contato encontrado");
                        break;
                    }
                    else{
                        for (int i = 0; i < agenda.size(); i++){
                                System.out.println("contato: "+ agenda.get(i).getNome());
                                System.out.println("telefone: "+ agenda.get(i).getTelefone());
                                System.out.println("id: "+ agenda.get(i).getId());
                                }
                            }
                case "q":
                    run = false;
                    break;
            }

        }

    }

}
