/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lab3ex3;

/**
 *
 * @author unifgcardoso
 */
public class Pessoa {
    private String nome;
    private int telefone,id;
    private static int contador = 0;

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getTelefone() {
        return telefone;
    }

    public void setTelefone(int telefone) {
        this.telefone = telefone;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Pessoa(String nome, int telefone) {
        this.nome = nome;
        this.telefone = telefone;
        id = contador + 1;
    }
    
    public static void mostraMenu(){
        System.out.println("Selecione uma opcao");
        System.out.println("(n)Para criar um novo contato");
        System.out.println("(d)Para apagar um contato");
        System.out.println("(p)Para imprimir a agenda");
        System.out.println("(q)Para sair do programa");
    }
    
    
}
